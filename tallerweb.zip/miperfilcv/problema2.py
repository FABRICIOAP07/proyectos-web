import pulp

model = pulp.LpProblem("transporte_coninventarios", pulp.LpMaximize)

plantas = ["A","B","C"]
distribuidores = ["D1","D2"]
tiendas = ["T1","T2","T3"]
meses = [1,2,3,4,5,6]

produccion = {"A":1000, "B":1200, "C":800}
costo_prod = {"A":10, "B":12, "C":9}
costo_PD = {("A","D1"):2,("A","D2"):1,("B","D1"):3,("B","D2"):3,("C","D1"):2,("C","D2"):2}
costo_DT = {("D1","T1"):1,("D1","T2"):2,("D1","T3"):2,("D2","T1"):2,("D2","T2"):1,("D2","T3"):2}
precio = {"T1":32, "T2":32, "T3":30}
h = {"D1":0.5, "D2":0.4}  
I_inicial = {"D1":50, "D2":100}

demanda = {
    (1,"T1"):300, (1,"T2"):250, (1,"T3"):200,
    (2,"T1"):350, (2,"T2"):300, (2,"T3"):220,
    (3,"T1"):400, (3,"T2"):320, (3,"T3"):250,
    (4,"T1"):370, (4,"T2"):310, (4,"T3"):230,
    (5,"T1"):360, (5,"T2"):330, (5,"T3"):240,
    (6,"T1"):380, (6,"T2"):340, (6,"T3"):260
}

X = pulp.LpVariable.dicts("X", [(i,j,t) for i in plantas for j in distribuidores for t in meses], lowBound=0)
Y = pulp.LpVariable.dicts("Y", [(j,k,t) for j in distribuidores for k in tiendas for t in meses], lowBound=0)
I = pulp.LpVariable.dicts("I", [(j,t) for j in distribuidores for t in meses], lowBound=0)

model += pulp.lpSum(
    precio[k]*Y[(j,k,t)]
    - (costo_prod[i]+costo_PD[(i,j)])*X[(i,j,t)]
    - costo_DT[(j,k)]*Y[(j,k,t)]
    - h[j]*I[(j,t)]
    for i in plantas for j in distribuidores for k in tiendas for t in meses
    if (i,j) in costo_PD and (j,k) in costo_DT
)

for i in plantas:
    for t in meses:
        model += pulp.lpSum([X[(i,j,t)] for j in distribuidores]) <= produccion[i]


for j in distribuidores:
    for t in meses:
        if t == 1:
            model += I[(j,t)] == I_inicial[j] + pulp.lpSum([X[(i,j,t)] for i in plantas]) - pulp.lpSum([Y[(j,k,t)] for k in tiendas])
        else:
            model += I[(j,t)] == I[(j,t-1)] + pulp.lpSum([X[(i,j,t)] for i in plantas]) - pulp.lpSum([Y[(j,k,t)] for k in tiendas])


for j in distribuidores:
    for t in meses:
        model += I[(j,t)] <= 2000


for k in tiendas:
    for t in meses:
        model += pulp.lpSum([Y[(j,k,t)] for j in distribuidores]) == demanda[(t,k)]

model.solve(pulp.PULP_CBC_CMD(msg=False))

print("estado:", pulp.LpStatus[model.status])
print("utilidad máxima:", pulp.value(model.objective))

print("\nInventarios por mes:")
for j in distribuidores:
    for t in meses:
        print(f"{j} mes {t}: {I[(j,t)].varValue:.0f}")
