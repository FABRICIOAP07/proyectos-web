import pulp

camiones = ['A', 'B', 'C', 'D']
rutas = ['R1', 'R2', 'R3', 'R4', 'R5', 'R6']

ganancias = {
    ('A', 'R1'):150, ('A','R2'):200, ('A','R3'):200, ('A','R4'):260, ('A','R5'):300, ('A','R6'):100,
    ('B', 'R1'):100, ('B','R2'):300, ('B','R3'):220, ('B','R4'):280, ('B','R5'):300, ('B','R6'):250,
    ('C', 'R1'):250, ('C','R2'):250, ('C','R3'):140, ('C','R4'):250, ('C','R5'):240, ('C','R6'):240,
    ('D', 'R1'):300, ('D','R2'):250, ('D','R3'):250, ('D','R4'):320, ('D','R5'):100, ('D','R6'):300,
}

modelo_a = pulp.LpProblem("Asignacion_Caso_A", pulp.LpMaximize)


x = pulp.LpVariable.dicts("x", (camiones, rutas), cat='Binary')

modelo_a += pulp.lpSum(ganancias[(c, r)] * x[c][r] for c in camiones for r in rutas)

for c in camiones:
    modelo_a += pulp.lpSum(x[c][r] for r in rutas) == 1

for r in rutas:
    modelo_a += pulp.lpSum(x[c][r] for c in camiones) <= 1

modelo_a += pulp.lpSum(x[c]['R2'] for c in camiones) == 1
modelo_a += pulp.lpSum(x[c]['R4'] for c in camiones) == 1


modelo_a.solve()

print("\n=== RESULTADOS CASO A ===")
print(f"Ganancia máxima: {pulp.value(modelo_a.objective)}")
for c in camiones:
    for r in rutas:
        if x[c][r].value() == 1:
            print(f"Camión {c} → Ruta {r} (Ganancia {ganancias[(c,r)]})")


modelo_b = pulp.LpProblem("Asignacion_Caso_B", pulp.LpMaximize)

y = pulp.LpVariable.dicts("y", (camiones, rutas), cat='Binary')

modelo_b += pulp.lpSum(ganancias[(c, r)] * y[c][r] for c in camiones for r in rutas)

for r in rutas:
    modelo_b += pulp.lpSum(y[c][r] for c in camiones) == 1

for c in camiones:
    modelo_b += pulp.lpSum(y[c][r] for r in rutas) >= 1


modelo_b.solve()

print("\n=== RESULTADOS CASO B ===")
print(f"Ganancia máxima: {pulp.value(modelo_b.objective)}")
for c in camiones:
    for r in rutas:
        if y[c][r].value() == 1:
            print(f"Camión {c} → Ruta {r} (Ganancia {ganancias[(c,r)]})")
